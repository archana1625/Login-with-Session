package com.example.aa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import static android.widget.Toast.makeText;


public class MainActivity extends AppCompatActivity {
    TextView reg;
    Button b1;
    EditText uname,pass;
    ProgressDialog dialog;
    private static final String KEY_STATUS = "status";
    private static final String KEY_EMPTY = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handleSSLHandshake();
        if(SharedPrefManager.getInstance(this).isLoggedIn()){
            finish();
            startActivity(new Intent(this,Home.class));
            return;
        }
        dialog = new ProgressDialog(this);

        b1=(Button) findViewById(R.id.managerLoginB);
        uname=(EditText)findViewById(R.id.managerUsername);
        pass=(EditText)findViewById(R.id.managerPassword);
        reg=(TextView)findViewById(R.id.forgetPassCus);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this,Register.class);
                    startActivity(intent);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (view == b1) {
                    if(haveNetwork())
                        registeruser();
                    else if (!haveNetwork()){
                        makeText(MainActivity.this,"No network",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


    } // end on create()


    private void registeruser() {
        if (validateInputs()) {
            final String username = uname.getText().toString().trim();
            final String password = pass.getText().toString().trim();
            //descr = desc_id.getText().toString().trim();
            //Photo = photo_id.getText().toString().trim();

            dialog.setMessage("Adding Information");

            dialog.show();

            System.out.println("##################################"+username+"##############################");
            System.out.println("##################################"+password+"##############################");
            JSONObject request = new JSONObject();
            try {
                //Populate the request parameters
                request.put("uname1",username);
                request.put("pass1",password);
                System.out.println("##################################  "+username+"  ##############################");
                System.out.println("##################################  "+password+"  ##############################");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            JsonObjectRequest stringRequest;
            stringRequest = new JsonObjectRequest
                    (Request.Method.POST, "https://192.168.42.62/loginuser.php", request, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            dialog.dismiss();
                            try {
                                if (response.getInt(KEY_STATUS) == 1) {
                                    SharedPrefManager.getInstance(getApplicationContext())
                                            .userLogin(
                                                    response.getString("username"),
                                                    response.getString("password")
                                            );
                                    Intent intent = new Intent(MainActivity.this,Home.class);
                                    startActivity(intent);

                                } else {
                                    makeText(getApplicationContext(),
                                            response.getString("something is wrong"), Toast.LENGTH_SHORT).show();
                                    makeText(getApplicationContext(),
                                            "Success", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            dialog.dismiss();
                            System.out.println("@@@@@@@@@@@@@@@@@@@@@  " + error.toString() + "  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                            //Display error message whenever an error occurs
                            makeText(getApplicationContext(),
                                    "error", Toast.LENGTH_SHORT).show();   ///errrrrrrrr

                        }
                    });

            RequestQueue requestQueue;
            requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }

    }


    /*public void gotoLogin(View view) {
        Intent intent = new Intent(Register_page.this, MainActivity.class);
        startActivity(intent);
    }*/


    public boolean haveNetwork() {

        boolean have_wifi = false;
        boolean have_mobiledata = false;
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo[] networkInfos = cm.getAllNetworkInfo();

        for (NetworkInfo info : networkInfos) {
            if (info.getTypeName().equalsIgnoreCase("WIFI"))
                if (info.isConnected())
                    have_wifi = true;
            if (info.getTypeName().equalsIgnoreCase("MOBILE"))
                if (info.isConnected())
                    have_mobiledata = true;

        }
        return have_mobiledata | have_wifi;
    }

    private boolean validateInputs() {
        if (KEY_EMPTY.equals(pass)) {
            pass.setError("Price cannot be empty");
            pass.requestFocus();
            return false;
        }
        if (KEY_EMPTY.equals(uname)) {
            uname.setError("Name cannot be empty");
            uname.requestFocus();
            return false;
        }

        return true;
    }

    @SuppressLint("TrulyRandom")
    public static void handleSSLHandshake() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    return true;
                }
            });
        } catch (Exception ignored) {
        }
    }




}// end mainactivity